FOR MY LOVELY AIN ♡ — WEBSITE FILES

Files:
- index.html
- photo1.jpeg through photo6.jpeg

To publish with GitHub Pages:
1. Create a new repository on GitHub.
2. Upload index.html and all six photo files into the repository's main/root folder.
3. Open Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the main branch and /(root), then Save.
6. Wait for GitHub Pages to publish the site; open the URL shown in Settings → Pages.

Keep the image filenames unchanged unless you also update the matching names in index.html.
The YouTube player needs an internet connection. The font also loads from Google Fonts, with a system-font fallback.
