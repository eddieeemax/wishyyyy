UPDATED WEBSITE FOR MY LOVELY AIN

Upload index.html and photo1.jpeg through photo6.jpeg into the SAME GitHub repository root folder.
Keep the exact filenames, including the .jpeg extension.
Only the birthday wish text is lowercase; other headings and sections use capital letters.
Punctuation is in standard English style: no space before commas/full stops and one space after them.
GitHub Pages: Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
